import { useCallback, useEffect, useRef, useState } from "react";

const GRID = 460;
const ROAD_WIDTH = 136;
const RUN_LENGTH = 90;
const SCORE_KEY = "neon-getaway-high-scores";

type Screen = "start" | "playing" | "paused" | "gameover";
type Axis = "horizontal" | "vertical";

type Building = {
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
  trim: string;
  units: { x: number; y: number; w: number; h: number }[];
};

type CityBlock = {
  buildings: Building[];
  trees: { x: number; y: number; radius: number }[];
  park: boolean;
};

type TrafficCar = {
  x: number;
  y: number;
  angle: number;
  speed: number;
  axis: Axis;
  dir: number;
  lane: number;
  color: string;
  missed: boolean;
};

type CopCar = {
  x: number;
  y: number;
  angle: number;
  speed: number;
  sirenOffset: number;
};

type Pickup = {
  x: number;
  y: number;
  phase: number;
  active: boolean;
  respawn: number;
};

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  square: boolean;
};

type FloatingText = {
  x: number;
  y: number;
  text: string;
  color: string;
  life: number;
  maxLife: number;
};

type TouchInput = {
  steer: number;
  vertical: number;
  gas: boolean;
  brake: boolean;
  drift: boolean;
  boost: boolean;
};

type Engine = {
  city: Map<string, CityBlock>;
  player: {
    x: number;
    y: number;
    angle: number;
    vx: number;
    vy: number;
    health: number;
    invulnerable: number;
  };
  traffic: TrafficCar[];
  cops: CopCar[];
  pickups: Pickup[];
  particles: Particle[];
  floaters: FloatingText[];
  keys: Set<string>;
  touch: TouchInput;
  cameraX: number;
  cameraY: number;
  score: number;
  cash: number;
  heat: number;
  timer: number;
  boost: number;
  combo: number;
  comboTimer: number;
  time: number;
  shake: number;
  boosting: boolean;
  wallCooldown: number;
  vehicleCooldown: number;
  copSpawnTimer: number;
  trailTimer: number;
  ended: boolean;
  reason: string;
};

type RunRecord = {
  score: number;
  cash: number;
  date: string;
  reason?: string;
};

type HudState = {
  score: number;
  cash: number;
  time: number;
  health: number;
  heat: number;
  boost: number;
  combo: number;
  speed: number;
};

const TRAFFIC_COLORS = ["#e9b866", "#85a7a4", "#c77468", "#d6d4c7", "#8993ba", "#ca8d4c"];
const ROOF_COLORS = ["#303a3c", "#343536", "#29363b", "#3a3738", "#353b37", "#2d3439"];
const TRIM_COLORS = ["#667472", "#777368", "#626d75", "#8a7167", "#647262"];

function clamp(value: number, min: number, max: number) {
  return Math.max(min, Math.min(max, value));
}

function seededRandom(seed: number) {
  let value = seed >>> 0;
  return () => {
    value += 0x6d2b79f5;
    let next = value;
    next = Math.imul(next ^ (next >>> 15), next | 1);
    next ^= next + Math.imul(next ^ (next >>> 7), next | 61);
    return ((next ^ (next >>> 14)) >>> 0) / 4294967296;
  };
}

function blockKey(x: number, y: number) {
  return `${x}:${y}`;
}

function createBuilding(x: number, y: number, w: number, h: number, random: () => number): Building {
  const units: Building["units"] = [];
  const count = 2 + Math.floor(random() * 4);
  for (let i = 0; i < count; i += 1) {
    const unitW = 15 + random() * 28;
    const unitH = 12 + random() * 25;
    units.push({
      x: x + 12 + random() * Math.max(4, w - unitW - 24),
      y: y + 12 + random() * Math.max(4, h - unitH - 24),
      w: unitW,
      h: unitH,
    });
  }
  return {
    x,
    y,
    w,
    h,
    color: ROOF_COLORS[Math.floor(random() * ROOF_COLORS.length)],
    trim: TRIM_COLORS[Math.floor(random() * TRIM_COLORS.length)],
    units,
  };
}

function createCityBlock(column: number, row: number): CityBlock {
  const blockSize = GRID - ROAD_WIDTH - 40;
  const random = seededRandom((row + 29) * 9127 + (column + 31) * 1879);
  const left = column * GRID + ROAD_WIDTH / 2 + 20;
  const top = row * GRID + ROAD_WIDTH / 2 + 20;
  const park = random() < 0.1;
  const block: CityBlock = { buildings: [], trees: [], park };

  if (park) {
    for (let tree = 0; tree < 7; tree += 1) {
      block.trees.push({
        x: left + 30 + random() * (blockSize - 60),
        y: top + 30 + random() * (blockSize - 60),
        radius: 8 + random() * 8,
      });
    }
  } else {
    const layout = Math.floor(random() * 4);
    const margin = 17;
    if (layout === 0) {
      block.buildings.push(createBuilding(left + 25, top + 24, blockSize - 50, blockSize - 48, random));
    } else if (layout === 1) {
      const half = (blockSize - 38) / 2;
      block.buildings.push(createBuilding(left + 12, top + 23, half, blockSize - 46, random));
      block.buildings.push(createBuilding(left + half + 26, top + 43, half - 1, blockSize - 86, random));
    } else if (layout === 2) {
      block.buildings.push(createBuilding(left + 24, top + 12, blockSize - 48, (blockSize - 34) * 0.52, random));
      block.buildings.push(createBuilding(left + 45, top + blockSize * 0.59, blockSize - 90, blockSize * 0.3, random));
    } else {
      block.buildings.push(createBuilding(left + margin, top + 19, blockSize * 0.57, blockSize - 38, random));
      block.buildings.push(createBuilding(left + blockSize * 0.66, top + 48, blockSize * 0.27, blockSize * 0.42, random));
    }
  }

  return block;
}

function getCityBlock(city: Map<string, CityBlock>, column: number, row: number) {
  const key = blockKey(column, row);
  let block = city.get(key);
  if (!block) {
    block = createCityBlock(column, row);
    city.set(key, block);
  }
  return block;
}

function createCity() {
  const city = new Map<string, CityBlock>();
  for (let row = -14; row <= 14; row += 1) {
    for (let column = -14; column <= 14; column += 1) {
      city.set(blockKey(column, row), createCityBlock(column, row));
    }
  }
  return city;
}

function createTraffic(): TrafficCar[] {
  const cars: TrafficCar[] = [];
  for (let i = 0; i < 17; i += 1) {
    const axis: Axis = Math.random() < 0.52 ? "horizontal" : "vertical";
    const dir = Math.random() < 0.5 ? -1 : 1;
    const lane = Math.random() < 0.5 ? -1 : 1;
    const row = Math.floor(Math.random() * 11) - 5;
    const along = (Math.random() * 10 - 5) * GRID;
    cars.push({
      x: axis === "horizontal" ? along : row * GRID + lane * 26,
      y: axis === "horizontal" ? row * GRID + lane * 26 : along,
      angle: axis === "horizontal" ? (dir > 0 ? Math.PI / 2 : -Math.PI / 2) : dir > 0 ? Math.PI : 0,
      speed: 78 + Math.random() * 76,
      axis,
      dir,
      lane,
      color: TRAFFIC_COLORS[Math.floor(Math.random() * TRAFFIC_COLORS.length)],
      missed: false,
    });
  }
  return cars;
}

function randomRoadPoint(centerX: number, centerY: number, spread: number) {
  if (Math.random() < 0.5) {
    const row = Math.round((centerY + (Math.random() - 0.5) * spread) / GRID);
    return { x: centerX + (Math.random() - 0.5) * spread, y: row * GRID + (Math.random() - 0.5) * 12 };
  }
  const column = Math.round((centerX + (Math.random() - 0.5) * spread) / GRID);
  return { x: column * GRID + (Math.random() - 0.5) * 12, y: centerY + (Math.random() - 0.5) * spread };
}

function createPickups(): Pickup[] {
  const placements = [
    { x: 0, y: -180 },
    { x: 190, y: 0 },
    { x: -205, y: 0 },
    { x: 0, y: 218 },
    { x: 440, y: 0 },
    { x: 0, y: -465 },
  ];
  const pickups: Pickup[] = placements.map((point) => ({ ...point, phase: Math.random() * Math.PI * 2, active: true, respawn: 0 }));

  for (let i = 0; i < 42; i += 1) {
    const point = randomRoadPoint(0, 0, GRID * 9);
    pickups.push({ ...point, phase: Math.random() * Math.PI * 2, active: true, respawn: 0 });
  }
  return pickups;
}

function makeTouchInput(): TouchInput {
  return { steer: 0, vertical: 0, gas: false, brake: false, drift: false, boost: false };
}

function createEngine(): Engine {
  return {
    city: createCity(),
    player: { x: 140, y: 10, angle: -0.6, vx: 0, vy: 0, health: 3, invulnerable: 0 },
    traffic: createTraffic(),
    cops: [],
    pickups: createPickups(),
    particles: [],
    floaters: [],
    keys: new Set<string>(),
    touch: makeTouchInput(),
    cameraX: 0,
    cameraY: 0,
    score: 0,
    cash: 0,
    heat: 0,
    timer: RUN_LENGTH,
    boost: 100,
    combo: 1,
    comboTimer: 0,
    time: 0,
    shake: 0,
    boosting: false,
    wallCooldown: 0,
    vehicleCooldown: 0,
    copSpawnTimer: 0,
    trailTimer: 0,
    ended: false,
    reason: "",
  };
}

function resetEngine(engine: Engine) {
  engine.player = { x: 0, y: 0, angle: 0, vx: 0, vy: 0, health: 3, invulnerable: 0 };
  engine.traffic = createTraffic();
  engine.cops = [];
  engine.pickups = createPickups();
  engine.particles = [];
  engine.floaters = [];
  engine.keys.clear();
  engine.touch = makeTouchInput();
  engine.cameraX = 0;
  engine.cameraY = 0;
  engine.score = 0;
  engine.cash = 0;
  engine.heat = 0;
  engine.timer = RUN_LENGTH;
  engine.boost = 100;
  engine.combo = 1;
  engine.comboTimer = 0;
  engine.time = 0;
  engine.shake = 0;
  engine.boosting = false;
  engine.wallCooldown = 0;
  engine.vehicleCooldown = 0;
  engine.copSpawnTimer = 0;
  engine.trailTimer = 0;
  engine.ended = false;
  engine.reason = "";
}

function addBurst(engine: Engine, x: number, y: number, count: number, colors: string[], power = 125) {
  for (let i = 0; i < count; i += 1) {
    const angle = Math.random() * Math.PI * 2;
    const speed = 28 + Math.random() * power;
    const life = 0.28 + Math.random() * 0.48;
    engine.particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      life,
      maxLife: life,
      size: 1.5 + Math.random() * 3.5,
      color: colors[Math.floor(Math.random() * colors.length)],
      square: Math.random() > 0.68,
    });
  }
  if (engine.particles.length > 360) engine.particles.splice(0, engine.particles.length - 360);
}

function addFloater(engine: Engine, x: number, y: number, text: string, color: string) {
  engine.floaters.push({ x, y, text, color, life: 1.05, maxLife: 1.05 });
  if (engine.floaters.length > 14) engine.floaters.shift();
}

function getNearbyBuildings(engine: Engine, x: number, y: number) {
  const column = Math.floor(x / GRID);
  const row = Math.floor(y / GRID);
  const nearby: Building[] = [];
  for (let blockY = row - 2; blockY <= row + 1; blockY += 1) {
    for (let blockX = column - 2; blockX <= column + 1; blockX += 1) {
      const block = getCityBlock(engine.city, blockX, blockY);
      nearby.push(...block.buildings);
    }
  }
  return nearby;
}

function resolveBuildingCollision(engine: Engine) {
  const player = engine.player;
  const radius = 13;
  let collided = false;

  for (const building of getNearbyBuildings(engine, player.x, player.y)) {
    const nearestX = clamp(player.x, building.x, building.x + building.w);
    const nearestY = clamp(player.y, building.y, building.y + building.h);
    let dx = player.x - nearestX;
    let dy = player.y - nearestY;
    let distance = Math.hypot(dx, dy);
    if (distance >= radius) continue;

    if (distance < 0.001) {
      const edges = [
        { distance: Math.abs(player.x - building.x), nx: -1, ny: 0, x: building.x - radius, y: player.y },
        { distance: Math.abs(building.x + building.w - player.x), nx: 1, ny: 0, x: building.x + building.w + radius, y: player.y },
        { distance: Math.abs(player.y - building.y), nx: 0, ny: -1, x: player.x, y: building.y - radius },
        { distance: Math.abs(building.y + building.h - player.y), nx: 0, ny: 1, x: player.x, y: building.y + building.h + radius },
      ].sort((a, b) => a.distance - b.distance);
      const edge = edges[0];
      player.x = edge.x;
      player.y = edge.y;
      dx = edge.nx;
      dy = edge.ny;
      distance = 1;
    } else {
      const nx = dx / distance;
      const ny = dy / distance;
      player.x = nearestX + nx * radius;
      player.y = nearestY + ny * radius;
      dx = nx;
      dy = ny;
    }

    const intoWall = player.vx * dx + player.vy * dy;
    if (intoWall < 0) {
      player.vx -= dx * intoWall * 1.55;
      player.vy -= dy * intoWall * 1.55;
    }
    player.vx *= 0.72;
    player.vy *= 0.72;
    collided = true;
  }

  return collided;
}

function damagePlayer(engine: Engine, x: number, y: number, reason: string) {
  const player = engine.player;
  if (player.invulnerable > 0) return;

  player.health = Math.max(0, player.health - 1);
  player.invulnerable = 1.2;
  engine.shake = Math.max(engine.shake, 13);
  addBurst(engine, x, y, 20, ["#ff624e", "#ffbd6c", "#edf0d3"], 155);
  addFloater(engine, x, y - 24, reason, "#ff806d");
  if (player.health === 0) engine.reason = "BUSTED";
}

function updateTraffic(engine: Engine, dt: number) {
  for (const car of engine.traffic) {
    if (car.axis === "horizontal") car.x += car.dir * car.speed * dt;
    else car.y += car.dir * car.speed * dt;

    if (Math.abs(car.x - engine.player.x) > 2450 || Math.abs(car.y - engine.player.y) > 2450) {
      const point = randomRoadPoint(engine.player.x, engine.player.y, 1800);
      if (car.axis === "horizontal") {
        car.x = point.x;
        car.y = Math.round(point.y / GRID) * GRID + car.lane * 26;
      } else {
        car.x = Math.round(point.x / GRID) * GRID + car.lane * 26;
        car.y = point.y;
      }
      car.missed = false;
    }
  }
}

function spawnCop(engine: Engine) {
  const playerColumn = Math.round(engine.player.x / GRID);
  const playerRow = Math.round(engine.player.y / GRID);
  const options = [
    [playerColumn + 3, playerRow],
    [playerColumn - 3, playerRow],
    [playerColumn, playerRow + 3],
    [playerColumn, playerRow - 3],
    [playerColumn + 2, playerRow - 2],
    [playerColumn - 2, playerRow + 2],
  ];
  const [column, row] = options[Math.floor(Math.random() * options.length)];
  engine.cops.push({ x: column * GRID, y: row * GRID, angle: 0, speed: 130, sirenOffset: Math.random() * 8 });
}

function updateCops(engine: Engine, dt: number) {
  const wanted = engine.heat >= 4.1 ? 3 : engine.heat >= 2.35 ? 2 : engine.heat >= 0.65 ? 1 : 0;
  while (engine.cops.length > wanted) engine.cops.pop();

  engine.copSpawnTimer -= dt;
  if (engine.cops.length < wanted && engine.copSpawnTimer <= 0) {
    spawnCop(engine);
    engine.copSpawnTimer = 2.6;
  }

  const player = engine.player;
  const nearestColumn = Math.round(player.x / GRID) * GRID;
  const nearestRow = Math.round(player.y / GRID) * GRID;
  const verticalRoad = Math.abs(player.x - nearestColumn) <= Math.abs(player.y - nearestRow);
  const targetX = verticalRoad ? nearestColumn : player.x;
  const targetY = verticalRoad ? player.y : nearestRow;

  for (const cop of engine.cops) {
    cop.speed = 138 + engine.heat * 15;
    const dy = targetY - cop.y;
    if (Math.abs(dy) > 10) {
      const step = Math.min(Math.abs(dy), cop.speed * dt) * Math.sign(dy);
      cop.y += step;
      cop.angle = step > 0 ? Math.PI : 0;
    } else {
      cop.y = targetY;
      const dx = targetX - cop.x;
      if (Math.abs(dx) > 10) {
        const step = Math.min(Math.abs(dx), cop.speed * dt) * Math.sign(dx);
        cop.x += step;
        cop.angle = step > 0 ? Math.PI / 2 : -Math.PI / 2;
      } else {
        cop.x = targetX;
      }
    }

    const distance = Math.hypot(player.x - cop.x, player.y - cop.y);
    if (distance < 33 && engine.vehicleCooldown <= 0) {
      const nx = (player.x - cop.x) / Math.max(distance, 1);
      const ny = (player.y - cop.y) / Math.max(distance, 1);
      player.x = cop.x + nx * 36;
      player.y = cop.y + ny * 36;
      player.vx += nx * 145;
      player.vy += ny * 145;
      engine.vehicleCooldown = 0.48;
      damagePlayer(engine, cop.x, cop.y, "SPIKE STRIP");
    }
  }
}

function updateGame(engine: Engine, dt: number, finishRun: (reason: string) => void) {
  const player = engine.player;
  const keys = engine.keys;
  const touch = engine.touch;
  engine.time += dt;
  engine.timer = Math.max(0, engine.timer - dt);
  engine.wallCooldown = Math.max(0, engine.wallCooldown - dt);
  engine.vehicleCooldown = Math.max(0, engine.vehicleCooldown - dt);
  player.invulnerable = Math.max(0, player.invulnerable - dt);
  engine.shake = Math.max(0, engine.shake - dt * 24);
  engine.heat = Math.max(0, engine.heat - dt * 0.008);

  if (engine.comboTimer > 0) engine.comboTimer -= dt;
  else engine.combo = Math.max(1, engine.combo - dt * 0.75);

  const left = keys.has("a") || keys.has("arrowleft");
  const right = keys.has("d") || keys.has("arrowright");
  const keyboardSteer = Number(right) - Number(left);
  const steer = clamp(keyboardSteer + touch.steer, -1, 1);
  const joyThrottle = clamp(-touch.vertical, 0, 1);
  const joyBrake = clamp(touch.vertical, 0, 1);
  const throttle = Math.max(Number(keys.has("w") || keys.has("arrowup")), Number(touch.gas), joyThrottle);
  const braking = Math.max(Number(keys.has("s") || keys.has("arrowdown")), Number(touch.brake), joyBrake);
  const drifting = keys.has(" ") || touch.drift;
  const boostInput = keys.has("shift") || touch.boost;
  engine.boosting = boostInput && engine.boost > 0.5 && Math.hypot(player.vx, player.vy) > 35;

  if (engine.boosting) engine.boost = Math.max(0, engine.boost - dt * 29);
  else engine.boost = Math.min(100, engine.boost + dt * 4.8);

  const forwardX = Math.sin(player.angle);
  const forwardY = -Math.cos(player.angle);
  let forwardSpeed = player.vx * forwardX + player.vy * forwardY;
  const acceleration = engine.boosting ? 440 : 310;

  if (throttle > 0) {
    player.vx += forwardX * acceleration * throttle * dt;
    player.vy += forwardY * acceleration * throttle * dt;
  }
  if (braking > 0) {
    const brakeForce = forwardSpeed > 24 ? 510 : 205;
    player.vx -= forwardX * brakeForce * braking * dt;
    player.vy -= forwardY * brakeForce * braking * dt;
  }

  const speed = Math.hypot(player.vx, player.vy);
  const turnRate = 0.48 + Math.min(speed / 200, 1.25) * 1.1;
  player.angle += steer * turnRate * (forwardSpeed < -15 ? -1 : 1) * (drifting ? 1.45 : 1) * dt;

  const newForwardX = Math.sin(player.angle);
  const newForwardY = -Math.cos(player.angle);
  forwardSpeed = player.vx * newForwardX + player.vy * newForwardY;
  const sideX = player.vx - newForwardX * forwardSpeed;
  const sideY = player.vy - newForwardY * forwardSpeed;
  const grip = Math.exp(-(drifting ? 0.38 : 7.8) * dt);
  const drag = Math.exp(-(throttle > 0 || braking > 0 ? 0.18 : 0.72) * dt);
  player.vx = (newForwardX * forwardSpeed + sideX * grip) * drag;
  player.vy = (newForwardY * forwardSpeed + sideY * grip) * drag;

  const maxSpeed = engine.boosting ? 515 : 348;
  const currentSpeed = Math.hypot(player.vx, player.vy);
  if (currentSpeed > maxSpeed) {
    player.vx = (player.vx / currentSpeed) * maxSpeed;
    player.vy = (player.vy / currentSpeed) * maxSpeed;
  }

  player.x += player.vx * dt;
  player.y += player.vy * dt;

  if (resolveBuildingCollision(engine) && engine.wallCooldown <= 0) {
    engine.wallCooldown = 0.28;
    engine.shake = Math.max(engine.shake, 6 + Math.min(currentSpeed / 50, 7));
    addBurst(engine, player.x, player.y, 8, ["#ffac65", "#f3d28d", "#9eafb0"], 95);
    if (currentSpeed > 135) damagePlayer(engine, player.x, player.y, "BODY WORK");
  }

  updateTraffic(engine, dt);
  for (const car of engine.traffic) {
    const dx = player.x - car.x;
    const dy = player.y - car.y;
    const distance = Math.hypot(dx, dy);

    if (distance > 95) car.missed = false;
    if (distance < 72 && distance > 34 && !car.missed) {
      car.missed = true;
      const reward = Math.round(160 * engine.combo);
      engine.score += reward;
      engine.combo = Math.min(4.5, engine.combo + 0.28);
      engine.comboTimer = 4.2;
      engine.heat = Math.min(5, engine.heat + 0.28);
      engine.boost = Math.min(100, engine.boost + 7);
      engine.shake = Math.max(engine.shake, 2.5);
      addFloater(engine, car.x, car.y - 24, `CLOSE CALL  +${reward}`, "#9fe8d4");
      addBurst(engine, player.x, player.y, 5, ["#b7ffe8", "#ffd07c"], 60);
    }

    if (distance < 31 && engine.vehicleCooldown <= 0) {
      const nx = dx / Math.max(distance, 1);
      const ny = dy / Math.max(distance, 1);
      player.x = car.x + nx * 35;
      player.y = car.y + ny * 35;
      player.vx += nx * 105;
      player.vy += ny * 105;
      engine.vehicleCooldown = 0.52;
      engine.shake = Math.max(engine.shake, 10);
      damagePlayer(engine, car.x, car.y, "TRAFFIC HIT");
    }
  }

  for (const pickup of engine.pickups) {
    if (!pickup.active) {
      pickup.respawn -= dt;
      if (pickup.respawn <= 0) {
        const point = randomRoadPoint(player.x, player.y, 1600);
        pickup.x = point.x;
        pickup.y = point.y;
        pickup.phase = Math.random() * Math.PI * 2;
        pickup.active = true;
      }
      continue;
    }

    if (Math.hypot(player.x - pickup.x, player.y - pickup.y) < 27) {
      const reward = Math.round(425 * engine.combo);
      engine.score += reward;
      engine.cash += 250;
      engine.combo = Math.min(4.5, engine.combo + 0.42);
      engine.comboTimer = 5.2;
      engine.heat = Math.min(5, engine.heat + 0.66);
      engine.boost = Math.min(100, engine.boost + 23);
      engine.shake = Math.max(engine.shake, 5.5);
      pickup.active = false;
      pickup.respawn = 8.5;
      addBurst(engine, pickup.x, pickup.y, 23, ["#ffd36f", "#fff0bd", "#8ce9d2"], 150);
      addFloater(engine, pickup.x, pickup.y - 28, `+$250  /  +${reward}`, "#ffd36f");
    }
  }

  updateCops(engine, dt);

  engine.trailTimer -= dt;
  if ((engine.boosting || (drifting && Math.hypot(player.vx, player.vy) > 115)) && engine.trailTimer <= 0) {
    engine.trailTimer = engine.boosting ? 0.035 : 0.07;
    const backX = player.x - Math.sin(player.angle) * 21;
    const backY = player.y + Math.cos(player.angle) * 21;
    const smoke = drifting && !engine.boosting;
    engine.particles.push({
      x: backX + (Math.random() - 0.5) * 8,
      y: backY + (Math.random() - 0.5) * 8,
      vx: (Math.random() - 0.5) * 36 - player.vx * 0.12,
      vy: (Math.random() - 0.5) * 36 - player.vy * 0.12,
      life: smoke ? 0.68 : 0.34,
      maxLife: smoke ? 0.68 : 0.34,
      size: smoke ? 8 + Math.random() * 7 : 3 + Math.random() * 4,
      color: smoke ? "#c4cfca" : "#ff6c3e",
      square: false,
    });
  }

  for (const particle of engine.particles) {
    particle.life -= dt;
    particle.x += particle.vx * dt;
    particle.y += particle.vy * dt;
    particle.vx *= Math.exp(-1.9 * dt);
    particle.vy *= Math.exp(-1.9 * dt);
  }
  engine.particles = engine.particles.filter((particle) => particle.life > 0);

  for (const floater of engine.floaters) {
    floater.life -= dt;
    floater.y -= 25 * dt;
  }
  engine.floaters = engine.floaters.filter((floater) => floater.life > 0);

  engine.cameraX += (player.x + player.vx * 0.2 - engine.cameraX) * Math.min(1, dt * 5.5);
  engine.cameraY += (player.y + player.vy * 0.2 - engine.cameraY) * Math.min(1, dt * 5.5);

  if (player.health <= 0) finishRun("BUSTED");
  else if (engine.timer <= 0) finishRun("TIME UP");
}

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, radius: number) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + width - r, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + r);
  ctx.lineTo(x + width, y + height - r);
  ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
  ctx.lineTo(x + r, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawRoads(ctx: CanvasRenderingContext2D, width: number, height: number, cameraX: number, cameraY: number) {
  const left = cameraX - width / 2 - GRID;
  const right = cameraX + width / 2 + GRID;
  const top = cameraY - height / 2 - GRID;
  const bottom = cameraY + height / 2 + GRID;
  const firstColumn = Math.floor(left / GRID);
  const lastColumn = Math.ceil(right / GRID);
  const firstRow = Math.floor(top / GRID);
  const lastRow = Math.ceil(bottom / GRID);

  ctx.fillStyle = "#1b2624";
  ctx.fillRect(left, top, right - left, bottom - top);

  for (let column = firstColumn; column <= lastColumn; column += 1) {
    const x = column * GRID;
    ctx.fillStyle = "#4b5654";
    ctx.fillRect(x - ROAD_WIDTH / 2, top, ROAD_WIDTH, bottom - top);
    ctx.fillStyle = "#303a3e";
    ctx.fillRect(x - ROAD_WIDTH / 2 + 10, top, ROAD_WIDTH - 20, bottom - top);
    ctx.fillStyle = "rgba(177, 193, 181, 0.14)";
    ctx.fillRect(x - ROAD_WIDTH / 2 + 10, top, 2, bottom - top);
    ctx.fillRect(x + ROAD_WIDTH / 2 - 12, top, 2, bottom - top);
  }

  for (let row = firstRow; row <= lastRow; row += 1) {
    const y = row * GRID;
    ctx.fillStyle = "#4b5654";
    ctx.fillRect(left, y - ROAD_WIDTH / 2, right - left, ROAD_WIDTH);
    ctx.fillStyle = "#303a3e";
    ctx.fillRect(left, y - ROAD_WIDTH / 2 + 10, right - left, ROAD_WIDTH - 20);
    ctx.fillStyle = "rgba(177, 193, 181, 0.14)";
    ctx.fillRect(left, y - ROAD_WIDTH / 2 + 10, right - left, 2);
    ctx.fillRect(left, y + ROAD_WIDTH / 2 - 12, right - left, 2);
  }

  ctx.strokeStyle = "rgba(242, 192, 109, 0.52)";
  ctx.lineWidth = 2;
  ctx.setLineDash([16, 22]);
  for (let column = firstColumn; column <= lastColumn; column += 1) {
    const x = column * GRID;
    ctx.beginPath();
    ctx.moveTo(x, top);
    ctx.lineTo(x, bottom);
    ctx.stroke();
  }
  for (let row = firstRow; row <= lastRow; row += 1) {
    const y = row * GRID;
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(right, y);
    ctx.stroke();
  }
  ctx.setLineDash([]);

  ctx.strokeStyle = "rgba(232, 236, 215, 0.28)";
  ctx.lineWidth = 2;
  for (let column = firstColumn; column <= lastColumn; column += 1) {
    for (let row = firstRow; row <= lastRow; row += 1) {
      const x = column * GRID;
      const y = row * GRID;
      for (let stripe = -2; stripe <= 2; stripe += 1) {
        ctx.beginPath();
        ctx.moveTo(x - 58 + stripe * 9, y - 57);
        ctx.lineTo(x - 58 + stripe * 9, y - 42);
        ctx.moveTo(x + 42 + stripe * 9, y + 42);
        ctx.lineTo(x + 42 + stripe * 9, y + 57);
        ctx.stroke();
      }
    }
  }
}

function drawBuilding(ctx: CanvasRenderingContext2D, building: Building) {
  ctx.fillStyle = "rgba(5, 9, 10, 0.55)";
  roundedRect(ctx, building.x + 7, building.y + 9, building.w, building.h, 5);
  ctx.fill();

  ctx.fillStyle = building.color;
  roundedRect(ctx, building.x, building.y, building.w, building.h, 5);
  ctx.fill();
  ctx.strokeStyle = "rgba(159, 177, 165, 0.28)";
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.strokeStyle = building.trim;
  ctx.globalAlpha = 0.52;
  ctx.lineWidth = 1;
  ctx.strokeRect(building.x + 8, building.y + 8, building.w - 16, building.h - 16);
  ctx.globalAlpha = 1;

  ctx.fillStyle = "rgba(13, 20, 22, 0.42)";
  for (const unit of building.units) {
    roundedRect(ctx, unit.x, unit.y, unit.w, unit.h, 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(152, 166, 157, 0.2)";
    ctx.stroke();
    ctx.fillStyle = "rgba(193, 200, 178, 0.12)";
    ctx.fillRect(unit.x + 4, unit.y + 4, Math.max(3, unit.w - 8), 2);
    ctx.fillStyle = "rgba(13, 20, 22, 0.42)";
  }

  ctx.fillStyle = "rgba(145, 160, 151, 0.12)";
  ctx.fillRect(building.x + 13, building.y + building.h - 15, building.w - 26, 2);
}

function drawCityBlocks(ctx: CanvasRenderingContext2D, engine: Engine, width: number, height: number) {
  const left = engine.cameraX - width / 2 - GRID;
  const right = engine.cameraX + width / 2 + GRID;
  const top = engine.cameraY - height / 2 - GRID;
  const bottom = engine.cameraY + height / 2 + GRID;
  const firstColumn = Math.floor(left / GRID) - 1;
  const lastColumn = Math.ceil(right / GRID);
  const firstRow = Math.floor(top / GRID) - 1;
  const lastRow = Math.ceil(bottom / GRID);

  for (let row = firstRow; row <= lastRow; row += 1) {
    for (let column = firstColumn; column <= lastColumn; column += 1) {
      const block = getCityBlock(engine.city, column, row);
      const x = column * GRID + ROAD_WIDTH / 2 + 20;
      const y = row * GRID + ROAD_WIDTH / 2 + 20;
      const size = GRID - ROAD_WIDTH - 40;

      if (block.park) {
        ctx.fillStyle = "#24332b";
        ctx.fillRect(x, y, size, size);
        ctx.strokeStyle = "rgba(132, 161, 124, 0.22)";
        ctx.lineWidth = 7;
        ctx.beginPath();
        ctx.moveTo(x + 16, y + size * 0.53);
        ctx.lineTo(x + size - 16, y + size * 0.47);
        ctx.moveTo(x + size * 0.47, y + 15);
        ctx.lineTo(x + size * 0.53, y + size - 15);
        ctx.stroke();
        for (const tree of block.trees) {
          ctx.fillStyle = "rgba(7, 12, 12, 0.42)";
          ctx.beginPath();
          ctx.arc(tree.x + 3, tree.y + 5, tree.radius + 1, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "#314b39";
          ctx.beginPath();
          ctx.arc(tree.x, tree.y, tree.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = "rgba(148, 177, 122, 0.2)";
          ctx.beginPath();
          ctx.arc(tree.x - 3, tree.y - 4, tree.radius * 0.48, 0, Math.PI * 2);
          ctx.fill();
        }
      } else {
        ctx.fillStyle = "#2a3231";
        ctx.fillRect(x, y, size, size);
        ctx.strokeStyle = "rgba(176, 181, 161, 0.08)";
        ctx.lineWidth = 1;
        for (let stripe = 0; stripe < 5; stripe += 1) {
          const lineX = x + 14 + stripe * (size - 28) / 4;
          ctx.beginPath();
          ctx.moveTo(lineX, y + 5);
          ctx.lineTo(lineX, y + size - 5);
          ctx.stroke();
        }
        for (const building of block.buildings) drawBuilding(ctx, building);
      }
    }
  }
}

function drawPickup(ctx: CanvasRenderingContext2D, pickup: Pickup, time: number) {
  const bob = Math.sin(time * 3.1 + pickup.phase) * 3;
  ctx.save();
  ctx.translate(pickup.x, pickup.y + bob);
  ctx.rotate(time * 0.7 + pickup.phase);
  ctx.globalAlpha = 0.24;
  ctx.fillStyle = "#ffd16c";
  ctx.beginPath();
  ctx.arc(0, 0, 23, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
  ctx.shadowColor = "#ffc858";
  ctx.shadowBlur = 17;
  ctx.fillStyle = "#f3bb55";
  ctx.beginPath();
  ctx.moveTo(0, -13);
  ctx.lineTo(12, 0);
  ctx.lineTo(0, 13);
  ctx.lineTo(-12, 0);
  ctx.closePath();
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.rotate(-(time * 0.7 + pickup.phase));
  ctx.fillStyle = "#fff1be";
  ctx.fillRect(-1, -6, 2, 12);
  ctx.fillRect(-5, -1, 10, 2);
  ctx.restore();
}

function drawCar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  angle: number,
  color: string,
  type: "player" | "traffic" | "police",
  time: number,
  invulnerable = false,
) {
  if (invulnerable && Math.floor(time * 17) % 2 === 0) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);

  ctx.fillStyle = "rgba(4, 8, 10, 0.58)";
  roundedRect(ctx, -13, -18, 26, 43, 6);
  ctx.fill();

  ctx.fillStyle = "#0d1215";
  ctx.fillRect(-15, -13, 4, 10);
  ctx.fillRect(11, -13, 4, 10);
  ctx.fillRect(-15, 8, 4, 10);
  ctx.fillRect(11, 8, 4, 10);

  const body = type === "police" ? "#d4ddd8" : color;
  ctx.fillStyle = body;
  roundedRect(ctx, -12, -21, 24, 42, 6);
  ctx.fill();
  ctx.strokeStyle = type === "player" ? "rgba(255, 227, 191, 0.72)" : "rgba(240, 244, 230, 0.4)";
  ctx.lineWidth = type === "player" ? 1.6 : 1;
  ctx.stroke();

  if (type === "police") {
    ctx.fillStyle = "#26343c";
    ctx.fillRect(-11, -2, 22, 5);
    ctx.fillStyle = "#1a2931";
    ctx.fillRect(-8, 3, 16, 3);
    const blink = Math.sin(time * 17) > 0;
    ctx.fillStyle = blink ? "#ff554e" : "#f7faf1";
    ctx.fillRect(-8, -13, 7, 4);
    ctx.fillStyle = blink ? "#f7faf1" : "#4bbde2";
    ctx.fillRect(1, -13, 7, 4);
    ctx.shadowColor = blink ? "#ff504a" : "#56c8ff";
    ctx.shadowBlur = 10;
    ctx.fillRect(-7, -12, 5, 2);
    ctx.fillRect(2, -12, 5, 2);
    ctx.shadowBlur = 0;
  } else {
    ctx.fillStyle = "rgba(11, 21, 26, 0.72)";
    roundedRect(ctx, -8, -13, 16, 24, 4);
    ctx.fill();
    ctx.fillStyle = "rgba(132, 182, 183, 0.62)";
    ctx.beginPath();
    ctx.moveTo(-7, -10);
    ctx.lineTo(7, -10);
    ctx.lineTo(6, -3);
    ctx.lineTo(-6, -3);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "rgba(90, 132, 138, 0.48)";
    ctx.fillRect(-6, 3, 12, 6);
    if (type === "player") {
      ctx.fillStyle = "rgba(255, 194, 104, 0.93)";
      ctx.shadowColor = "#ffc56b";
      ctx.shadowBlur = 8;
      ctx.fillRect(-9, -20, 5, 2);
      ctx.fillRect(4, -20, 5, 2);
      ctx.shadowBlur = 0;
    } else {
      ctx.fillStyle = "#ff6255";
      ctx.fillRect(-9, 18, 5, 2);
      ctx.fillRect(4, 18, 5, 2);
    }
  }

  if (type === "player") {
    ctx.fillStyle = "#ff6255";
    ctx.fillRect(-9, 18, 5, 2);
    ctx.fillRect(4, 18, 5, 2);
    ctx.fillStyle = "rgba(255, 255, 255, 0.28)";
    ctx.fillRect(-1, -18, 2, 30);
  }
  ctx.restore();
}

function drawParticles(ctx: CanvasRenderingContext2D, engine: Engine) {
  for (const particle of engine.particles) {
    const alpha = clamp(particle.life / particle.maxLife, 0, 1);
    ctx.globalAlpha = alpha * (particle.color === "#c4cfca" ? 0.48 : 0.9);
    ctx.fillStyle = particle.color;
    if (particle.square) ctx.fillRect(particle.x - particle.size / 2, particle.y - particle.size / 2, particle.size, particle.size);
    else {
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size * alpha, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.globalAlpha = 1;

  for (const floater of engine.floaters) {
    ctx.globalAlpha = clamp(floater.life / floater.maxLife, 0, 1);
    ctx.textAlign = "center";
    ctx.font = "800 12px Arial, sans-serif";
    ctx.letterSpacing = "1px";
    ctx.shadowColor = "rgba(0,0,0,0.7)";
    ctx.shadowBlur = 7;
    ctx.fillStyle = floater.color;
    ctx.fillText(floater.text, floater.x, floater.y);
    ctx.shadowBlur = 0;
  }
  ctx.globalAlpha = 1;
}

function drawScene(ctx: CanvasRenderingContext2D, width: number, height: number, engine: Engine, screen: Screen) {
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "#121b1d";
  ctx.fillRect(0, 0, width, height);

  const shake = screen === "playing" ? engine.shake : 0;
  const shakeX = (Math.random() - 0.5) * shake;
  const shakeY = (Math.random() - 0.5) * shake;
  ctx.save();
  ctx.translate(width / 2 - engine.cameraX + shakeX, height / 2 - engine.cameraY + shakeY);
  drawRoads(ctx, width, height, engine.cameraX, engine.cameraY);
  drawCityBlocks(ctx, engine, width, height);

  for (const pickup of engine.pickups) {
    if (pickup.active && Math.abs(pickup.x - engine.cameraX) < width * 0.7 && Math.abs(pickup.y - engine.cameraY) < height * 0.7) {
      drawPickup(ctx, pickup, engine.time);
    }
  }

  for (const car of engine.traffic) drawCar(ctx, car.x, car.y, car.angle, car.color, "traffic", engine.time);
  for (const cop of engine.cops) drawCar(ctx, cop.x, cop.y, cop.angle, "#d4ddd8", "police", engine.time + cop.sirenOffset);

  if (engine.boosting && screen === "playing") {
    ctx.save();
    ctx.translate(engine.player.x, engine.player.y);
    ctx.rotate(engine.player.angle);
    ctx.globalAlpha = 0.78;
    ctx.fillStyle = "#ff6e3d";
    ctx.shadowColor = "#ff603f";
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.moveTo(-6, 17);
    ctx.lineTo(0, 34 + Math.random() * 7);
    ctx.lineTo(6, 17);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  const playerColor = screen === "start" ? "#eb6d52" : "#ee7654";
  drawCar(ctx, engine.player.x, engine.player.y, engine.player.angle, playerColor, "player", engine.time, screen === "playing" && engine.player.invulnerable > 0);
  drawParticles(ctx, engine);
  ctx.restore();
}

function readHighScores(): RunRecord[] {
  if (typeof window === "undefined") return [];
  try {
    const saved = window.localStorage.getItem(SCORE_KEY);
    if (!saved) return [];
    const parsed: unknown = JSON.parse(saved);
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((entry): entry is RunRecord => Boolean(entry && typeof entry.score === "number" && typeof entry.cash === "number" && typeof entry.date === "string"))
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);
  } catch {
    return [];
  }
}

function formatScore(value: number) {
  return Math.floor(value).toLocaleString("en-US");
}

function formatTime(value: number) {
  const safe = Math.max(0, Math.ceil(value));
  return `${String(Math.floor(safe / 60)).padStart(2, "0")}:${String(safe % 60).padStart(2, "0")}`;
}

function makeHud(engine: Engine): HudState {
  return {
    score: engine.score,
    cash: engine.cash,
    time: engine.timer,
    health: engine.player.health,
    heat: engine.heat,
    boost: engine.boost,
    combo: engine.combo,
    speed: Math.round(Math.hypot(engine.player.vx, engine.player.vy) * 0.62),
  };
}

function Leaderboard({ scores }: { scores: RunRecord[] }) {
  return (
    <div className="leaderboard">
      <div className="leaderboard-heading">
        <span>LOCAL BEST</span>
        <span>TOP 03</span>
      </div>
      {scores.length === 0 ? (
        <p className="leaderboard-empty">NO RUNS LOGGED <span>MAKE THE FIRST ONE COUNT</span></p>
      ) : (
        <ol>
          {scores.slice(0, 3).map((run, index) => (
            <li key={`${run.date}-${index}`}>
              <span className="leader-rank">0{index + 1}</span>
              <span className="leader-name">NIGHT RUNNER</span>
              <strong>{formatScore(run.score)}</strong>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  if (!engineRef.current) engineRef.current = createEngine();
  const engine = engineRef.current;

  const [screen, setScreen] = useState<Screen>("start");
  const screenRef = useRef<Screen>("start");
  const [scores, setScores] = useState<RunRecord[]>(readHighScores);
  const [lastRun, setLastRun] = useState<RunRecord | null>(null);
  const [hud, setHud] = useState<HudState>(() => makeHud(engine));
  const [stickPosition, setStickPosition] = useState({ x: 0, y: 0 });
  const stickPointer = useRef<number | null>(null);
  const finishRunRef = useRef<(reason: string) => void>(() => undefined);

  const changeScreen = useCallback((next: Screen) => {
    screenRef.current = next;
    setScreen(next);
  }, []);

  const startRun = useCallback(() => {
    resetEngine(engineRef.current!);
    setLastRun(null);
    setHud(makeHud(engineRef.current!));
    setStickPosition({ x: 0, y: 0 });
    changeScreen("playing");
  }, [changeScreen]);

  const finishRun = useCallback((reason: string) => {
    const current = engineRef.current!;
    if (current.ended) return;
    current.ended = true;
    current.reason = reason;
    const record: RunRecord = {
      score: current.score,
      cash: current.cash,
      date: new Date().toISOString(),
      reason,
    };
    const nextScores = [...readHighScores(), record].sort((a, b) => b.score - a.score).slice(0, 5);
    try {
      window.localStorage.setItem(SCORE_KEY, JSON.stringify(nextScores));
    } catch {
      // The run still ends normally when storage is unavailable.
    }
    setScores(nextScores);
    setLastRun(record);
    screenRef.current = "gameover";
    setScreen("gameover");
  }, []);
  finishRunRef.current = finishRun;

  const clearInputs = useCallback(() => {
    engineRef.current!.keys.clear();
    engineRef.current!.touch = makeTouchInput();
    stickPointer.current = null;
    setStickPosition({ x: 0, y: 0 });
  }, []);

  const pauseRun = useCallback(() => {
    if (screenRef.current !== "playing") return;
    clearInputs();
    changeScreen("paused");
  }, [changeScreen, clearInputs]);

  const resumeRun = useCallback(() => {
    if (screenRef.current !== "paused") return;
    changeScreen("playing");
  }, [changeScreen]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas?.getContext("2d", { alpha: false });
    if (!canvas || !context) return;

    let width = 0;
    let height = 0;
    let pixelRatio = 1;
    let animationId = 0;
    let lastFrame = performance.now();
    let hudAt = 0;

    const resize = () => {
      const bounds = canvas.getBoundingClientRect();
      width = Math.max(1, bounds.width);
      height = Math.max(1, bounds.height);
      pixelRatio = Math.min(window.devicePixelRatio || 1, 1.7);
      canvas.width = Math.round(width * pixelRatio);
      canvas.height = Math.round(height * pixelRatio);
      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    };

    const frame = (now: number) => {
      const dt = Math.min((now - lastFrame) / 1000, 0.04);
      lastFrame = now;
      const activeEngine = engineRef.current!;
      const activeScreen = screenRef.current;

      if (activeScreen === "playing") updateGame(activeEngine, dt, (reason) => finishRunRef.current(reason));
      else if (activeScreen !== "paused") {
        activeEngine.time += dt;
        updateTraffic(activeEngine, dt);
      }

      if (activeScreen === "playing" && now >= hudAt) {
        hudAt = now + 90;
        setHud(makeHud(activeEngine));
      }

      context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
      drawScene(context, width, height, activeEngine, screenRef.current);
      animationId = window.requestAnimationFrame(frame);
    };

    resize();
    window.addEventListener("resize", resize);
    animationId = window.requestAnimationFrame(frame);
    return () => {
      window.cancelAnimationFrame(animationId);
      window.removeEventListener("resize", resize);
    };
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(key)) event.preventDefault();
      if (event.repeat && !["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright", "shift", " "].includes(key)) return;

      if (key === "escape") {
        if (screenRef.current === "playing") pauseRun();
        else if (screenRef.current === "paused") resumeRun();
        return;
      }
      if (key === "r" && screenRef.current !== "start") {
        startRun();
        return;
      }
      if ((key === "enter" || key === " ") && screenRef.current === "start") {
        startRun();
        return;
      }
      if ((key === "enter" || key === " ") && screenRef.current === "gameover") {
        startRun();
        return;
      }
      if (key === "enter" && screenRef.current === "paused") {
        resumeRun();
        return;
      }
      if (screenRef.current === "playing") engineRef.current!.keys.add(key);
    };

    const onKeyUp = (event: KeyboardEvent) => engineRef.current!.keys.delete(event.key.toLowerCase());
    const onBlur = () => clearInputs();
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    return () => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
    };
  }, [clearInputs, pauseRun, resumeRun, startRun]);

  const setTouch = (field: "gas" | "brake" | "drift" | "boost", value: boolean) => {
    engineRef.current!.touch[field] = value;
  };

  const updateStick = (event: React.PointerEvent<HTMLDivElement>) => {
    const bounds = event.currentTarget.getBoundingClientRect();
    const radius = Math.min(bounds.width, bounds.height) * 0.34;
    const dx = event.clientX - (bounds.left + bounds.width / 2);
    const dy = event.clientY - (bounds.top + bounds.height / 2);
    const distance = Math.hypot(dx, dy);
    const scale = distance > radius ? radius / distance : 1;
    const x = clamp((dx * scale) / radius, -1, 1);
    const y = clamp((dy * scale) / radius, -1, 1);
    engineRef.current!.touch.steer = x;
    engineRef.current!.touch.vertical = y;
    setStickPosition({ x: x * 35, y: y * 35 });
  };

  const handleStickDown = (event: React.PointerEvent<HTMLDivElement>) => {
    event.preventDefault();
    stickPointer.current = event.pointerId;
    event.currentTarget.setPointerCapture(event.pointerId);
    updateStick(event);
  };

  const handleStickMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (stickPointer.current !== event.pointerId) return;
    updateStick(event);
  };

  const handleStickUp = (event: React.PointerEvent<HTMLDivElement>) => {
    if (stickPointer.current !== event.pointerId) return;
    stickPointer.current = null;
    engineRef.current!.touch.steer = 0;
    engineRef.current!.touch.vertical = 0;
    setStickPosition({ x: 0, y: 0 });
  };

  const touchButton = (field: "gas" | "brake" | "drift" | "boost", label: string, className: string) => (
    <button
      className={`touch-button ${className}`}
      type="button"
      aria-label={label}
      onPointerDown={(event) => {
        event.preventDefault();
        event.currentTarget.setPointerCapture(event.pointerId);
        setTouch(field, true);
      }}
      onPointerUp={() => setTouch(field, false)}
      onPointerCancel={() => setTouch(field, false)}
      onLostPointerCapture={() => setTouch(field, false)}
    >
      <span>{label}</span>
    </button>
  );

  const isActive = screen === "playing" || screen === "paused" || screen === "gameover";
  const timeCritical = hud.time <= 15;

  return (
    <main className={`game-shell screen-${screen}`}>
      <canvas ref={canvasRef} className="city-canvas" aria-hidden="true" />
      <div className="scene-vignette" aria-hidden="true" />
      <div className="scene-grain" aria-hidden="true" />

      <header className={`topbar ${isActive ? "topbar-active" : ""}`}>
        <div className="brand-lockup" aria-label="Neon Getaway, Pacific City">
          <span className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 32 32" fill="none">
              <path d="M7 25V7h4.4l9.2 11.4V7H25v18h-4.1l-9.5-11.7V25H7Z" fill="currentColor" />
              <path d="M4 28h24" stroke="currentColor" strokeWidth="1.5" opacity=".45" />
            </svg>
          </span>
          <span className="brand-name">NEON <b>GETAWAY</b></span>
          <span className="brand-location">PACIFIC CITY / DISTRICT 09</span>
        </div>

        {isActive && (
          <div className="run-hud" aria-live="polite">
            <div className="hud-score">
              <span className="hud-label">SCORE</span>
              <strong>{formatScore(hud.score)}</strong>
              {hud.combo > 1.15 && <em>x{hud.combo.toFixed(1)}</em>}
            </div>
            <div className={`hud-time ${timeCritical ? "time-critical" : ""}`}>
              <span className="hud-label">TIME</span>
              <strong>{formatTime(hud.time)}</strong>
            </div>
            <div className="hud-heat">
              <span className="hud-label">HEAT</span>
              <div className="heat-bars" aria-label={`${Math.ceil(hud.heat)} out of 5 heat`}>{[0, 1, 2, 3, 4].map((level) => <i key={level} className={hud.heat >= level + 0.65 ? "lit" : ""} />)}</div>
            </div>
            <div className="hud-boost">
              <span className="hud-label">NITRO</span>
              <div className="boost-track"><i style={{ width: `${hud.boost}%` }} /></div>
            </div>
            <div className="hud-health">
              <span className="hud-label">RIDE</span>
              <div>{[0, 1, 2].map((level) => <i key={level} className={hud.health > level ? "healthy" : ""} />)}</div>
            </div>
          </div>
        )}

        {screen === "playing" ? (
          <button className="pause-trigger" type="button" onClick={pauseRun} aria-label="Pause game">
            <span className="pause-glyph"><i /><i /></span>
            <span>PAUSE</span>
          </button>
        ) : screen === "start" ? (
          <div className="top-note"><span className="live-dot" /> NIGHT SHIFT // 01:37 AM</div>
        ) : null}
      </header>

      {screen === "start" && (
        <section className="start-screen" aria-label="Start Neon Getaway">
          <div className="start-layout">
            <div className="hero-copy">
              <p className="eyebrow"><span /> A CITY THAT NEVER SLEEPS</p>
              <h1>NEON<br /><span>GETAWAY</span></h1>
              <p className="hero-description">One last score. <strong>One loud exit.</strong><br />Hit the streets, stack cash, and lose the lights.</p>
              <button className="start-button" type="button" onClick={startRun}>
                <span>START NIGHT RUN</span>
                <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 10h13M10 4l6 6-6 6" /></svg>
              </button>
              <div className="start-prompt">90 SECOND SPRINT <span>/</span> PRESS ENTER</div>
              <div className="control-guide" aria-label="Keyboard controls">
                <span><kbd>WASD</kbd><small>DRIVE</small></span>
                <span><kbd>SPACE</kbd><small>HAND BRAKE</small></span>
                <span><kbd>SHIFT</kbd><small>NITRO</small></span>
              </div>
              <p className="touch-hint">TOUCH: STEER LEFT / TAP GO, DRIFT, OR NITRO</p>
            </div>

            <aside className="title-side">
              <div className="district-mark"><span>09</span><div><b>THE MARINA DISTRICT</b><small>LOCAL TIME 01:37:42 AM</small></div></div>
              <Leaderboard scores={scores} />
            </aside>
          </div>
          <div className="screen-index"><span>01</span> / THE GETAWAY</div>
        </section>
      )}

      {screen === "playing" && (
        <>
          <div className="drive-readout" aria-live="polite">
            <span>{Math.round(hud.speed).toString().padStart(3, "0")}</span><small>MPH</small>
          </div>
          <div className="objective-line"><span className="objective-dot" /> GRAB THE CASH. STAY OUT OF CUFFS.</div>

          <div className="touch-controls" aria-label="Touch driving controls">
            <div
              className="joystick"
              onPointerDown={handleStickDown}
              onPointerMove={handleStickMove}
              onPointerUp={handleStickUp}
              onPointerCancel={handleStickUp}
              onLostPointerCapture={handleStickUp}
            >
              <span className="stick-direction stick-up" />
              <span className="stick-direction stick-down" />
              <span className="stick-direction stick-left" />
              <span className="stick-direction stick-right" />
              <span className="stick-knob" style={{ transform: `translate(${stickPosition.x}px, ${stickPosition.y}px)` }} />
              <span className="stick-caption">STEER</span>
            </div>
            <div className="touch-actions">
              {touchButton("brake", "BRAKE", "touch-brake")}
              {touchButton("boost", "NITRO", "touch-nitro")}
              {touchButton("drift", "DRIFT", "touch-drift")}
              {touchButton("gas", "GO", "touch-go")}
            </div>
          </div>
        </>
      )}

      {screen === "paused" && (
        <section className="state-overlay" aria-label="Game paused">
          <div className="state-panel">
            <p className="eyebrow"><span /> ENGINE IDLING</p>
            <h2>PAUSED<span>.</span></h2>
            <p className="state-copy">The city can wait. The cops won't.</p>
            <div className="state-actions">
              <button className="start-button" type="button" onClick={resumeRun}><span>BACK TO THE RUN</span><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 10h13M10 4l6 6-6 6" /></svg></button>
              <button className="text-action" type="button" onClick={startRun}>RESTART RUN <span>R</span></button>
            </div>
            <div className="state-footnote"><kbd>ESC</kbd> RESUME <span>/</span> KEEP MOVING</div>
          </div>
        </section>
      )}

      {screen === "gameover" && (
        <section className="state-overlay gameover-overlay" aria-label="Run complete">
          <div className="gameover-layout">
            <div className="state-panel result-panel">
              <p className="eyebrow"><span /> RUN COMPLETE / PACIFIC CITY</p>
              <h2>{lastRun?.reason ?? "NIGHT OVER"}<span>.</span></h2>
              <p className="state-copy">The streets remember. The score is yours.</p>
              <div className="result-score"><span>FINAL SCORE</span><strong>{formatScore(lastRun?.score ?? hud.score)}</strong><i>${formatScore(lastRun?.cash ?? hud.cash)} CASH LIFTED</i></div>
              <div className="state-actions">
                <button className="start-button" type="button" onClick={startRun}><span>RUN IT BACK</span><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 10h13M10 4l6 6-6 6" /></svg></button>
                <button className="text-action" type="button" onClick={() => changeScreen("start")}>BACK TO TITLE</button>
              </div>
              <div className="state-footnote"><kbd>ENTER</kbd> INSTANT RESTART <span>/</span> <kbd>R</kbd> RETRY</div>
            </div>
            <div className="result-board"><Leaderboard scores={scores} /></div>
          </div>
        </section>
      )}

      <footer className={`bottom-note ${screen === "playing" ? "bottom-note-playing" : ""}`}>
        <span>NEON GETAWAY</span><i /> BUILT FOR THE LONG WAY HOME
      </footer>
    </main>
  );
}